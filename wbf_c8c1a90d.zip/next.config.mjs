/** @type {import('next').NextConfig} */
const nextConfig = {
    images: {
        domains: ['github.com', 'i.pravatar.cc'],
    },
};

export default nextConfig;
